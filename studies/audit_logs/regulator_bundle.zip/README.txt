mr-audit Export Bundle
=======================

This bundle was produced by mr-audit (https://github.com/ayk5511/mr-audit)
on 2026-04-28T21:08:40.152408+00:00 UTC.

Source log:    /Users/akmbp/Documents/EB1A-Profile/papers/paper4-audit-trail/studies/audit_logs/paper2_demo.db
Records:       6825

Contents
--------
manifest.json           Bundle metadata + SHA-256 of every contents file
audit_records.jsonl     All audit records, one per line, canonical JSON
chain_verification.json Hash-chain verification at export time
manifest.sha256         Off-the-shelf integrity check on manifest.json
README.txt              This file

Verification (without mr-audit installed)
------------------------------------------
1. Compute SHA-256 of manifest.json:
       sha256sum manifest.json
   Compare to manifest.sha256.

2. For each file listed in manifest.json's `files` field, compute SHA-256:
       sha256sum <filename>
   Compare to the digest in manifest.json.

Replay (with mr-audit installed)
---------------------------------
    pip install mr-audit
    mr-audit verify <path-to-bundle.zip>
    mr-audit replay <path-to-bundle.zip> --record-id <id>
